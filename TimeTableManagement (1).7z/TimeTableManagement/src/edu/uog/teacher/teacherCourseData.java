package edu.uog.teacher;

public class teacherCourseData {

}
