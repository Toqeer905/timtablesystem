package edu.uog.timetable;

public class timeSlotData {

}
