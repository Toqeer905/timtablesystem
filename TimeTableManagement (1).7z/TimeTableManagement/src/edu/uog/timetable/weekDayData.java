package edu.uog.timetable;

public class weekDayData {

}
