package edu.uog.timetable;

public class timeTableData {

}
